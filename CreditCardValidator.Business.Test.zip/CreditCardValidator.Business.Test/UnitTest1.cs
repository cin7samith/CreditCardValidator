﻿using System;
using System.Linq;
using Xunit;

namespace CreditCardValidator.Business.Test
{
    public class UnitTest1
    {
        [Fact]
        public void TestMethod1()
        {
        }
    }
}
